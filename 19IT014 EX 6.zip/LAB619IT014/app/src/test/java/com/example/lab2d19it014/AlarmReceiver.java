package com.example.lab2d19it014;

public class AlarmReceiver {
}
